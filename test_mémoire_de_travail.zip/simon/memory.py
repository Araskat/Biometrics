import pseudo
import csv

#variable globale
new_dict = {}


def save_pseudo():
    liste_pseudo = []
    pseudo_save = pseudo.enter()
    liste_pseudo.append(pseudo_save)
    return liste_pseudo
    
    
def save_score(score):
    liste_score = []
    liste_score.append(score)
    return liste_score

def save_all(liste_pseudo, liste_score):
    global new_dict
    for i in range (len(liste_pseudo)):
        new_dict[liste_pseudo[i]] = liste_score[i]
    with open("tableau_score.csv", 'a') as f:
        writer =csv.writer(f)
        for a,b in new_dict.items():
            writer.writerow([a,b])
    f.close()