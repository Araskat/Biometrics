import tkinter as tk
import pandas as pd

def csv_change():
    dict_from_csv = pd.read_csv('tableau_score.csv', header=None, index_col=0, squeeze=True).to_dict()
    return dict_from_csv

def affichage_score():
    fenetre = tk.Tk()
    label_titre=tk.Label(fenetre, text="pseudo   score")
    label_titre.pack()
    doc = csv_change()
    couple =''
    for i,j in doc.items():
        couple = i,j
        label = tk.Label(fenetre, text=couple)
        label.pack()
    fenetre.mainloop()