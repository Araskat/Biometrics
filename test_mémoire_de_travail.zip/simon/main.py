import game


game.start_menu()