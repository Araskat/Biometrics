from tkinter import Tk, StringVar, Label, Entry, Button


def update_label(label, stringvar):

    text = stringvar.get()
    label.config(text=text)



def close_window(root):
    root.destroy()
    
def enter():
    root = Tk()
    text = StringVar(root)
    label = Label(root, text='Veuillez vous identifier')
    entry_name = Entry(root, textvariable=text)
    button = Button(root, text='Confirmer', command=lambda:close_window(root))



    label.grid(column=0, row=0)
    entry_name.grid(column=0, row=1)
    button.grid(column=0, row=2)

    root.mainloop()

    return text.get()